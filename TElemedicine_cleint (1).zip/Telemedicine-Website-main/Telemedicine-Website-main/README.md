# Telemedicine Website
Front end done upto landing page,Team Page and chatbot added(Using Dialogflow)
## Home Page
![image](https://user-images.githubusercontent.com/62868878/128900590-e66a14c4-7f54-4730-b04c-286fbe25503a.png)
